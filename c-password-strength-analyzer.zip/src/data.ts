// Data structures for the C-Based Password Strength Checker IDE & Simulator

export interface CSourceFile {
  name: string;
  language: string;
  content: string;
}

export const DEFAULT_C_CODE = `/**
 * @file main.c
 * @brief Cyber Security Mini-Project: Password Strength Checker
 * @description Analyzes user passwords against key cybersecurity criteria in C.
 * Designed as a beginner-friendly internship project with detailed comments.
 * 
 * Target: Advanced string evaluation using basic C constructs.
 */

#include <stdio.h>
#include <string.h>
#include <ctype.h>

// Minimum length requirement for a secure password
#define MIN_LENGTH 8

// Maximum buffer size to prevent buffer overflow attacks
#define MAX_SIZE 100

// Function prototypes to declare implementation signatures
void check_password_strength(const char *password);
int has_special_character(const char *password);

int main() {
    char password[MAX_SIZE];
    char choice;

    printf("==================================================\\n");
    printf("   CYBERSECURITY PASSWORD STRENGTH CHECKER (C)     \\n");
    printf("==================================================\\n");
    printf("Welcome to the Security Assessment Tool.\\n");
    printf("This program evaluates password complexity to prevent generic attacks.\\n\\n");

    do {
        printf("Enter a password to analyze (Max %d characters): ", MAX_SIZE - 1);
        
        // Securely read string from standard input to prevent Buffer Overflow vulnerability
        // fgets is preferred over gets() or scanf because it limits read size
        if (fgets(password, sizeof(password), stdin) != NULL) {
            // Remove the trailing newline character added by fgets
            password[strcspn(password, "\\n")] = '\\0';
            
            // Check if user just pressed enter (empty input)
            if (strlen(password) == 0) {
                printf("\\n[ERROR] Password cannot be empty. Please try again.\\n");
                continue;
            }

            // Perform Cybersecurity Strength Analysis
            check_password_strength(password);
        }

        printf("\\nDo you want to check another password? (y/n): ");
        scanf(" %c", &choice);
        
        // Clear input buffer (crucia C programming practice to prevent character trapping)
        while (getchar() != '\\n'); 
        printf("\\n");

    } while (choice == 'y' || choice == 'Y');

    printf("Assessment complete. Exit. Maintain strong passwords!\\n");
    printf("==================================================\\n");

    return 0;
}

/**
 * Checks if the string contains at least one special character
 * @param password The target string
 * @return 1 if found, 0 otherwise
 */
int has_special_character(const char *password) {
    // Standard special symbols in cybersecurity policies (no unescaped quotes or backticks)
    const char *special_symbols = "!@#$%^&*()-_=+[{]};:,.<>?/|~";
    
    // Using string handling pointer search - strchr
    for (int i = 0; password[i] != '\\0'; i++) {
        if (strchr(special_symbols, password[i]) != NULL) {
            return 1; // Found standard special symbol
        }
    }
    return 0;
}

/**
 * Core Assessment Engine
 * Examines password entropy and compliance against cybersecurity rules.
 * @param password The password string
 */
void check_password_strength(const char *password) {
    int length = strlen(password);
    int has_upper = 0;
    int has_lower = 0;
    int has_digit = 0;
    int has_special = 0;

    // Multi-criteria checking using a loop and character classification functions
    for (int i = 0; i < length; i++) {
        if (isupper((unsigned char)password[i])) {
            has_upper = 1;
        } else if (islower((unsigned char)password[i])) {
            has_lower = 1;
        } else if (isdigit((unsigned char)password[i])) {
            has_digit = 1;
        }
    }
    
    // Check for special characters using custom pointer function
    has_special = has_special_character(password);

    // Score computation (Total metrics satisfied)
    int criteria_met = 0;
    if (length >= MIN_LENGTH) criteria_met++;
    if (has_upper) criteria_met++;
    if (has_lower) criteria_met++;
    if (has_digit) criteria_met++;
    if (has_special) criteria_met++;

    // Print Detailed Cybersecurity Analysis Report
    printf("\\n--- SECURITY ANALYSIS REPORT ---\\n");
    printf("Password Evaluated: \\"%s\\"\\n", password);
    printf("Total Length: %d characters (Required: %d+)\\n", length, MIN_LENGTH);
    printf("--------------------------------\\n");
    
    // Display each checklist item with security status
    printf("1. Length Check       : %s\\n", (length >= MIN_LENGTH) ? "[PASS]" : "[FAIL (Too Short)]");
    printf("2. Uppercase Letter   : %s\\n", (has_upper) ? "[PASS]" : "[FAIL (Missing A-Z)]");
    printf("3. Lowercase Letter   : %s\\n", (has_lower) ? "[PASS]" : "[FAIL (Missing a-z)]");
    printf("4. Digit / Number     : %s\\n", (has_digit) ? "[PASS]" : "[FAIL (Missing 0-9)]");
    printf("5. Special Character  : %s\\n", (has_special) ? "[PASS]" : "[FAIL (Missing symbols)]");
    printf("--------------------------------\\n");

    // Output final classification based on cybersecurity requirements
    printf("Strength Status       : ");
    if (criteria_met <= 2) {
        printf("WEAK  (Score: %d/5) [CRITICALLY VULNERABLE]\\n", criteria_met);
        printf("Recommendation        : Attackers can crack this easily. Combine uppercase, digits, and symbols.\\n");
    } else if (criteria_met == 3 || criteria_met == 4) {
        printf("MEDIUM (Score: %d/5) [MINIMALLY COMPLIANT]\\n", criteria_met);
        printf("Recommendation        : Fairly decent but could be stronger. Ensure length is > 8 with all character sets.\\n");
    } else if (criteria_met == 5) {
        printf("STRONG (Score: %d/5) [EXCELLENT STRENGTH]\\n", criteria_met);
        printf("Recommendation        : High entropy, meets major corporate audit standards.\\n");
    }
    printf("--------------------------------\\n");
}
`;

export interface GuideSection {
  title: string;
  category: string;
  description: string;
  codeSnippet: string;
  explanation: string;
}

export const COMPILATION_GUIDE = `### How to Compile & Run Your C Program Locally

To present this as a fully functional offline project for an internship, you should run it on your local system using any of the following methods.

#### Method 1: Using GCC Compiler (Recommended)
GCC is the industry standard compiler for C/C++ in Linux, macOS, and Windows (via MinGW).

1. **Install GCC:**
   - **Windows:** Download & install **MinGW-w64** (or use MSYS2) and add it to your PATH.
   - **macOS:** Open terminal and run \`xcode-select --install\` to set up Clang/GCC.
   - **Linux:** Run \`sudo apt update && sudo apt install build-essential\` on Ubuntu/Debian.

2. **Save String Code:**
   Create a filename named \`pwstrength.c\` and paste the source code.

3. **Compile via Terminal:**
   \`\`\`bash
   gcc pwstrength.c -o pwstrength
   \`\`\`

4. **Execute the Binary:**
   - On **Linux / macOS**: \`./pwstrength\`
   - On **Windows**: \`pwstrength.exe\`

---

#### Method 2: Using IDEs (Code::Blocks, CLion, or VS Code)
- **Visual Studio Code:** Install the **C/C++** extension by Microsoft, install GCC MinGW, and press \`Ctrl+F5\` to compile.
- **Code::Blocks:** A great beginner-friendly absolute wrapper IDE. Paste the code into a new C project and click the green 'Build and Run' icon.
- **Online GDB Debugger:** A quick, browser-based sandbox to verify C parameters instantly.
`;

export const CYBERSECURITY_CONCEPTS_GUIDE: GuideSection[] = [
  {
    title: "1. Buffer Overflow Prevention (fgets vs scanf)",
    category: "Vulnerability Protection",
    description: "In C, input buffers have fixed limits. A classic attack vector is sending input longer than the target container, overwriting stack registers to hijack the thread.",
    codeSnippet: `// ❌ VULNERABLE: easily overflows memory if input exceeds 99 chars
char password[100];
scanf("%s", password); 

// ✅ SECURE PRACTICE: blocks characters beyond size limit automatically
char password[100];
fgets(password, sizeof(password), stdin);`,
    explanation: "Our code uses 'fgets' which guarantees it never writes outside the bounds of the static character array. We also cleanly strip the newline character via `strcspn()`."
  },
  {
    title: "2. Char Set Analysis using standard <ctype.h>",
    category: "Standard Libraries",
    description: "Built-in macros return boolean flags evaluating ASCII boundaries. They run extremely fast and safely with no manual condition range failures.",
    codeSnippet: `isupper((unsigned char)c); // Returns true if c is 'A'-'Z'
islower((unsigned char)c); // Returns true if c is 'a'-'z'
isdigit((unsigned char)c); // Returns true if c is '0'-'9'`,
    explanation: "C character functions should cast to (unsigned char) to prevent undefined behavior when handling wide character sets."
  },
  {
    title: "3. Modular Function Offloading",
    category: "Software Engineering",
    description: "Offloading string operations into functions (like 'has_special_character') makes the program cleanly readable, reusable, and easy to unit test.",
    codeSnippet: `int has_special_character(const char *password) {
    const char *symbols = "!@#$%^&*()-_=+[{]};:,.<>?/|~";
    for (int i = 0; password[i] != '\\0'; i++) {
        if (strchr(symbols, password[i]) != NULL)
            return 1;
    }
    return 0;
}`,
    explanation: "This leverages standard C's strchr() to check if individual character pointers exist within our specialized security symbol list."
  },
  {
    title: "4. Password Strength & Entropy Policy",
    category: "Security Policy",
    description: "Modern criteria require meeting multi-factor policies. A strong password combines at least 4 independent criteria and satisfies a standard minimum length.",
    codeSnippet: `// Scoring policy applied:
// Criteria satisfied counts (0 to 5 points)
int criteria_met = (len >= 8) + upper + lower + digit + special;
if (criteria_met == 5) {
    // SECURE HIGH ENTROPY
}`,
    explanation: "A password length of 8 with combinations reaches decent cryptographic complexity, avoiding offline dictionary-based brute force lookup vectors."
  }
];

export interface QuizQuestion {
  id: number;
  question: string;
  choices: string[];
  correctIndex: number;
  explanation: string;
}

export const FAQS = [
  {
    q: "Why is C used for cyber security projects?",
    a: "C is a low-level language. Understanding systems memory, direct pointer indexing, memory limits, and libraries gives cyber security professionals deep insights into how core kernels, compilers, and vulnerabilities (like buffer injection or memory leaks) operate."
  },
  {
    q: "How can I demonstrate this project for an internship?",
    a: "Open this project on your system via GCC/VS Code. Run it and demonstrate how passwords of varying formats are evaluated. Discuss the transition from scanf() to fgets() as a critical safety decision. The detailed slide report and certificate emulator in this app will help you prepare."
  },
  {
    q: "Does this program store the parsed password?",
    a: "No, this program evaluates the password entirely in temporary RAM and does not write it to a database, satisfying zero-retention security guidelines."
  },
  {
    q: "How are uppercase/lowercase characters mapped?",
    a: "They are mapped index-by-index in memory based on standard ASCII integer keys (e.g., 'A' is 65, 'Z' is 90). <ctype.h> checks these ranges."
  }
];

export const QUIZ_QUESTIONS: QuizQuestion[] = [
  {
    id: 1,
    question: "Which of the following functions is a secure choice in C to read a password input and prevent a 'buffer overflow' attack?",
    choices: [
      "gets(password);",
      "scanf(\"%s\", password);",
      "fgets(password, sizeof(password), stdin);",
      "strcpy(password, global_input);"
    ],
    correctIndex: 2,
    explanation: "fgets() lets you specify maximum capacity, preventing data from bleeding into adjacent stack registers. gets() is completely deprecated due to severe security vulnerabilities."
  },
  {
    id: 2,
    question: "What header file do functions like isupper(), islower(), and isdigit() belong to?",
    choices: [
      "<stdio.h>",
      "<string.h>",
      "<ctype.h>",
      "<stdlib.h>"
    ],
    correctIndex: 2,
    explanation: "<ctype.h> contains character classification functions that inspect ASCII character groups safely."
  },
  {
    id: 3,
    question: "What is the purpose of the line 'password[strcspn(password, \"\\n\")] = '\\0';' in C?",
    choices: [
      "It checks if the password has a special character",
      "It removes the trailing newline character appended by fgets",
      "It encrypts the password with null characters",
      "It checks characters up to the null termination index"
    ],
    correctIndex: 1,
    explanation: "fgets keeps the return key 'Enter' (\\n) in the string buffer. To get the correct strlen() and match passwords cleanly, we swap the '\\n' with a null terminator '\\0'."
  },
  {
    id: 4,
    question: "Why should we cast the character to (unsigned char) inside character classification macros, e.g., isupper((unsigned char)password[i]);?",
    choices: [
      "Because characters in C can be signed, leading to undefined array indexing behavior on non-ASCII characters.",
      "Because uppercase characters have larger integers.",
      "To save double memory space on the stack.",
      "To invoke the compiler optimizer block."
    ],
    correctIndex: 0,
    explanation: "C character functions take integers that represent unsigned char values or EOF. Passing signed values can trigger undefined array offsets under various standard library backends."
  }
];
