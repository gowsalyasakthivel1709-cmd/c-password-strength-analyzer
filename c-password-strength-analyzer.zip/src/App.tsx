import React, { useState } from "react";
import { 
  ShieldCheck, 
  Terminal, 
  Check, 
  X, 
  Lock, 
  Unlock, 
  ShieldAlert, 
  Key,
  Database,
  History,
  Info
} from "lucide-react";

interface LogType {
  timestamp: string;
  type: "info" | "error" | "success" | "warning";
  text: string;
}

export default function App() {
  // Master correct password (original password) set as "S3cur1ty_Pa$$2026!"
  const [targetPassword, setTargetPassword] = useState("S3cur1ty_Pa$$2026!");
  const [enteredPassword, setEnteredPassword] = useState("");
  
  // Attempts tracking state
  const [attempts, setAttempts] = useState(0);
  const maxAttempts = 3;
  const isLocked = attempts >= maxAttempts;

  // Authentication Status Feed
  const [authStatus, setAuthStatus] = useState<"idle" | "granted" | "failed" | "locked" | "unlocked_success">("idle");
  const [feedbackMessage, setFeedbackMessage] = useState("Awaiting security audit input...");
  
  // Real-time firewall terminal log states
  const [logs, setLogs] = useState<LogType[]>([
    { timestamp: "15:40:05", type: "info", text: "Secure auth protection module initialized." },
    { timestamp: "15:40:06", type: "info", text: "Lockout security system standing by. Retry limit: 3." }
  ]);

  // Helper to add logs inside the simulated C-terminal terminal
  const addLog = (text: string, type: "info" | "error" | "success" | "warning" = "info") => {
    const time = new Date().toLocaleTimeString('en-US', { hour12: false, hour: '2-digit', minute: '2-digit', second: '2-digit' });
    setLogs(prev => [{ timestamp: time, type, text }, ...prev.slice(0, 14)]);
  };

  // Evaluate Password Strength parameters
  const minLength = 8;
  const len = enteredPassword.length;
  const hasUpper = /[A-Z]/.test(enteredPassword);
  const hasLower = /[a-z]/.test(enteredPassword);
  const hasDigit = /[0-9]/.test(enteredPassword);
  const hasSpecial = /[!@#$%^&*()\-_=+\[{\]};:',.<>?/|~]/.test(enteredPassword);

  let score = 0;
  if (len >= minLength) score++;
  if (hasUpper) score++;
  if (hasLower) score++;
  if (hasDigit) score++;
  if (hasSpecial) score++;

  const getStrengthCategory = () => {
    if (enteredPassword.length === 0) {
      return { 
        label: "NOT ENTERED", 
        color: "text-slate-500", 
        percentage: 0 
      };
    }
    if (score <= 2) {
      return { 
        label: "Weak", 
        color: "text-rose-400 drop-shadow-[0_0_8px_rgba(244,63,94,0.4)] font-black", 
        percentage: 25 
      };
    }
    if (score <= 4) {
      return { 
        label: "Medium", 
        color: "text-amber-400 drop-shadow-[0_0_8px_rgba(251,191,36,0.4)] font-black", 
        percentage: 65 
      };
    }
    return { 
      label: "Strong", 
      color: "text-emerald-400 drop-shadow-[0_0_12px_rgba(52,211,153,0.5)] font-black uppercase tracking-wider", 
      percentage: 100 
    };
  };

  const strength = getStrengthCategory();

  // Dynamic system security recommendations based on current input buffer
  const getSecurityTips = () => {
    const tips = [];
    if (len < minLength) {
      tips.push(`Increase overall password length to at least ${minLength} characters (current length: ${len})`);
    }
    if (!hasUpper) {
      tips.push("Enforce uppercase letters (A-Z) to defend against dictionary attacks");
    }
    if (!hasLower) {
      tips.push("Inject lowercase letters (a-z) for standard system entropy compliance");
    }
    if (!hasDigit) {
      tips.push("Include numerical values (0-9) to disrupt mathematical brute-force attempts");
    }
    if (!hasSpecial) {
      tips.push("Introduce special symbols (e.g. !, @, #, $, %, *) to satisfy cyber complexity rules");
    }

    if (tips.length === 0 && enteredPassword.length > 0) {
      return ["✓ Excellent! This password fulfills optimal cryptographic standards."];
    }
    if (enteredPassword.length === 0) {
      return ["Input a test string above to generate optimization suggestions."];
    }
    return tips;
  };

  // Submit Handler for Authentication or System Recovery
  const handleSystemAction = (e?: React.FormEvent) => {
    if (e) e.preventDefault();

    if (!enteredPassword) {
      addLog("Attempt rejected: Input buffer is void.", "warning");
      return;
    }

    if (isLocked) {
      // Recovery phase: User is attempting to unlock with the original password
      addLog(`System is locked. Testing recovery key: "${enteredPassword}"...`, "info");
      
      if (enteredPassword === targetPassword) {
        setAttempts(0);
        setAuthStatus("unlocked_success");
        setFeedbackMessage("Account Unlocked Successfully");
        setEnteredPassword("");
        addLog("Account Unlocked Successfully. Login privileges restored.", "success");
      } else {
        setAuthStatus("locked");
        setFeedbackMessage("Account Locked! Wrong unlock password.");
        addLog("Unlock Failed: Invalid recovery signature. Access denied.", "error");
      }
    } else {
      // Normal authentication phase
      addLog(`Scanning input buffer: "${enteredPassword}"...`, "info");

      if (enteredPassword === targetPassword) {
        setAuthStatus("granted");
        setFeedbackMessage("Access Granted");
        // Reset count upon successful log-in
        setAttempts(0);
        addLog("System Status verified. Access Granted.", "success");
      } else {
        const currentAttempts = attempts + 1;
        setAttempts(currentAttempts);
        const remaining = maxAttempts - currentAttempts;

        if (currentAttempts >= maxAttempts) {
          setAuthStatus("locked");
          setFeedbackMessage("Account Locked!");
          addLog("System Breach Warning! Threshold exceeded.", "error");
          addLog("Account Locked! Too many failed attempts.", "error");
        } else {
          setAuthStatus("failed");
          setFeedbackMessage(`Wrong password. Remaining attempts: ${remaining}`);
          addLog(`Password mismatch. Attempts used: ${currentAttempts}/${maxAttempts}`, "warning");
        }
      }
    }
  };

  return (
    <div className="min-h-screen bg-[#07080B] text-slate-300 flex flex-col font-sans relative antialiased selection:bg-cyan-500 selection:text-slate-900">
      
      {/* BACKGROUND GRAPHIC GLOW EFFECTS */}
      <div className="absolute inset-0 bg-[linear-gradient(to_right,#0F1116_1px,transparent_1px),linear-gradient(to_bottom,#0F1116_1px,transparent_1px)] bg-[size:4rem_4rem] [mask-image:radial-gradient(ellipse_60%_50%_at_50%_0%,#000_70%,transparent_100%)] pointer-events-none" />
      <div className="absolute top-0 left-1/2 -translate-x-1/2 w-full max-w-5xl h-[320px] bg-cyan-950/10 rounded-full blur-[100px] pointer-events-none" />

      {/* HEADER SECTION */}
      <header className="relative z-10 flex items-center justify-between px-6 md:px-10 py-4 border-b border-white/5 bg-[#0A0B0E]/85 backdrop-blur-md">
        <div className="flex items-center space-x-3">
          <div className="p-1 px-2 pb-1 bg-cyan-950/40 border border-cyan-800/30 rounded-md text-[10px] font-mono tracking-wider text-cyan-400 font-extrabold flex items-center gap-1.5 shadow-[0_0_12px_rgba(34,211,238,0.1)]">
            <Terminal className="h-3.5 w-3.5" />
            SECURE C CONTROLLER
          </div>
          <span className="text-xs uppercase tracking-widest text-slate-500 font-bold hidden sm:inline">Simulated Security Gate</span>
        </div>
        
        <div className="flex items-center space-x-4 text-[10px] font-mono uppercase tracking-wider text-slate-500">
          <span className="flex items-center gap-1">
            <span className="h-2 w-2 rounded-full bg-cyan-500"></span> RETRY LIMIT: 3
          </span>
          <span className="px-2 py-0.5 border border-white/5 bg-white/[0.01] rounded-full text-slate-400">
            Hacker Shield Active
          </span>
        </div>
      </header>

      {/* CENTERED LAYOUT */}
      <main className="relative z-10 flex-1 flex flex-col items-center justify-center p-4 md:p-8 max-w-4xl mx-auto w-full">
        
        {/* POLISHED MAIN TITLE */}
        <div className="text-center mb-8 max-w-lg">
          <h1 className="text-3xl md:text-5xl font-light text-white mb-2 tracking-tight flex items-center justify-center gap-3">
            <ShieldCheck className="h-8 w-8 md:h-12 md:w-12 text-cyan-400 drop-shadow-[0_0_8px_rgba(34,211,238,0.3)]" />
            <span className="font-extrabold text-transparent bg-clip-text bg-gradient-to-r from-white via-slate-100 to-slate-400">
              Password Strength Checker
            </span>
          </h1>
          <p className="text-slate-500 text-xs tracking-wider font-mono uppercase bg-slate-950/40 py-1 px-3.5 rounded-full inline-block border border-white/[0.03]">
            3-Attempt Security Lockout & Account Recovery Simulator
          </p>
        </div>

        {/* PRIMARY CONTROL TERMINAL CARD */}
        <div className="w-full max-w-2xl bg-[#0C0D12] border border-white/10 rounded-2xl p-6 md:p-8 shadow-[0_20px_50px_rgba(0,0,0,0.85)] relative overflow-hidden" id="password-strength-checker-app">
          
          <div className="absolute top-0 left-0 w-full h-[1px] bg-gradient-to-r from-transparent via-cyan-500/50 to-transparent" />
          
          {/* SECURE LOCK STATUS BLOCK */}
          <div className="mb-6 flex flex-wrap items-center justify-between gap-4 p-4 rounded-xl border border-white/5 bg-slate-950/65 relative">
            <div className="flex items-center space-x-3.5">
              <div className={`p-3 rounded-lg shrink-0 transition-colors ${
                isLocked 
                  ? "bg-rose-950/40 border border-rose-500/40 text-rose-400 animate-pulse" 
                  : authStatus === "granted"
                  ? "bg-emerald-950/40 border border-emerald-500/40 text-emerald-400"
                  : authStatus === "unlocked_success"
                  ? "bg-cyan-950/40 border border-cyan-500/40 text-cyan-400"
                  : "bg-slate-900 border border-white/5 text-slate-400"
              }`}>
                {isLocked ? (
                  <Lock className="h-5 w-5" />
                ) : authStatus === "granted" ? (
                  <Unlock className="h-5 w-5" />
                ) : (
                  <Key className="h-5 w-5" />
                )}
              </div>
              
              <div>
                <dt className="text-[9px] uppercase tracking-widest text-slate-500 font-mono">Authentication Status</dt>
                {isLocked ? (
                  <dd className="text-sm font-black text-rose-400 uppercase tracking-wider flex items-center gap-1">
                    Account Locked!
                  </dd>
                ) : authStatus === "granted" ? (
                  <dd className="text-sm font-black text-emerald-400 uppercase tracking-wider">
                    Access Granted
                  </dd>
                ) : authStatus === "unlocked_success" ? (
                  <dd className="text-sm font-black text-cyan-400 uppercase tracking-wider">
                    Unlocked Successfully
                  </dd>
                ) : (
                  <dd className="text-xs font-mono text-slate-400">
                    Enter password to prompt system
                  </dd>
                )}
              </div>
            </div>

            {/* LED STATUS LIGHTS */}
            <div className="text-right">
              <span className="text-[9px] uppercase tracking-widest text-slate-500 font-mono block mb-1">
                Security Retries ({maxAttempts - attempts} remaining)
              </span>
              <div className="flex items-center justify-end space-x-2.5">
                {[1, 2, 3].map((num) => (
                  <div 
                    key={num}
                    className={`h-2.5 w-6 rounded border transition-all duration-350 ${
                      attempts >= num 
                        ? "bg-rose-600/50 border-rose-500 shadow-[0_0_8px_rgba(239,68,68,0.5)]" 
                        : "bg-black/50 border-white/10"
                    }`}
                  />
                ))}
              </div>
            </div>
          </div>

          {/* DYNAMIC SYSTEM DIALOGUE FEEDBACK MESSAGE */}
          <div className={`mb-6 p-3 rounded-lg text-center font-mono text-xs border ${
            isLocked 
              ? "bg-rose-950/20 border-rose-900/30 text-rose-300"
              : authStatus === "granted"
              ? "bg-emerald-950/20 border-emerald-900/30 text-emerald-300"
              : authStatus === "unlocked_success"
              ? "bg-cyan-950/20 border-cyan-900/30 text-cyan-300"
              : "bg-slate-950/40 border-white/5 text-slate-450"
          }`}>
            <span className="text-[10px] text-slate-500 uppercase tracking-widest mr-2">[SYSTEM RESPONSE]</span> 
            <span className="font-bold">{feedbackMessage}</span>
          </div>

          <form onSubmit={handleSystemAction} className="space-y-6">
            
            {/* INPUT FIELD */}
            <div>
              <div className="flex justify-between items-center mb-2">
                <label className="text-[10px] uppercase tracking-widest text-slate-400 font-mono flex items-center gap-1.5">
                  <Terminal className="h-4 w-4 text-cyan-400 animate-pulse" /> 
                  {isLocked ? "Recovery Input (Admin Password)" : "Evaluate / Test Passcode"}
                </label>
                
                {/* Master Reference Trigger */}
                <div className="flex items-center space-x-2 text-[10px] font-mono text-slate-500">
                  <span>Match Reference:</span>
                  <button 
                    type="button"
                    onClick={() => {
                      setEnteredPassword(targetPassword);
                      addLog(`Referenced key value: "${targetPassword}" populated.`, "info");
                    }}
                    className="text-cyan-400 hover:text-cyan-300 font-bold bg-cyan-950/30 px-2 py-0.5 border border-cyan-800/20 rounded hover:underline"
                  >
                    "{targetPassword}"
                  </button>
                </div>
              </div>

              <div className="relative">
                <input 
                  type="text" 
                  value={enteredPassword}
                  onChange={(e) => {
                    setEnteredPassword(e.target.value);
                    if (authStatus !== "idle" && authStatus !== "locked") {
                      setAuthStatus("idle");
                    }
                  }}
                  placeholder={
                    isLocked 
                      ? "Account is Locked! Enter Admin password to restore access..." 
                      : "Type password here to audit complexity..."
                  }
                  autoFocus
                  className={`w-full bg-[#07080B] border font-mono text-sm md:text-base rounded-xl px-4 py-4 pr-24 focus:outline-none transition-all shadow-inner ${
                    isLocked 
                      ? "border-rose-500/40 text-rose-400 focus:border-rose-500 placeholder-rose-750" 
                      : authStatus === "granted"
                      ? "border-emerald-500/50 text-emerald-400 focus:border-emerald-500"
                      : "border-white/10 text-white focus:border-cyan-500/50"
                  }`}
                />
                
                <div className="absolute right-3.5 top-1/2 -translate-y-1/2 flex items-center space-x-1.5 bg-[#12141F] border border-white/10 px-2.5 py-0.5 rounded">
                  <span className="text-[9px] font-mono uppercase text-slate-500">Len:</span>
                  <span className="text-xs font-mono font-bold text-cyan-400">{len}</span>
                </div>
              </div>
            </div>

            {/* REAL-TIME CHARACTERISTIC ASSESSMENTS */}
            <div className="grid grid-cols-2 md:grid-cols-5 gap-2">
              <div className={`p-2.5 rounded-lg border text-center transition-all ${len >= minLength ? 'bg-emerald-950/15 border-emerald-500/30 text-emerald-400' : 'bg-slate-950/25 border-white/5 text-slate-600'}`}>
                <div className="text-[9px] font-mono uppercase text-slate-500">Len &ge; 8</div>
                <div className="text-xs font-bold mt-1 font-mono">{len >= minLength ? "PASSED" : "FAILED"}</div>
              </div>
              <div className={`p-2.5 rounded-lg border text-center transition-all ${hasUpper ? 'bg-emerald-950/15 border-emerald-500/30 text-emerald-400' : 'bg-slate-950/25 border-white/5 text-slate-600'}`}>
                <div className="text-[9px] font-mono uppercase text-slate-500">Upper [A-Z]</div>
                <div className="text-xs font-bold mt-1 font-mono">{hasUpper ? "PASSED" : "FAILED"}</div>
              </div>
              <div className={`p-2.5 rounded-lg border text-center transition-all ${hasLower ? 'bg-emerald-950/15 border-emerald-500/30 text-emerald-400' : 'bg-slate-950/25 border-white/5 text-slate-600'}`}>
                <div className="text-[9px] font-mono uppercase text-slate-500">Lower [a-z]</div>
                <div className="text-xs font-bold mt-1 font-mono">{hasLower ? "PASSED" : "FAILED"}</div>
              </div>
              <div className={`p-2.5 rounded-lg border text-center transition-all ${hasDigit ? 'bg-emerald-950/15 border-emerald-500/30 text-emerald-400' : 'bg-slate-950/25 border-white/5 text-slate-600'}`}>
                <div className="text-[9px] font-mono uppercase text-slate-500">Digit [0-9]</div>
                <div className="text-xs font-bold mt-1 font-mono">{hasDigit ? "PASSED" : "FAILED"}</div>
              </div>
              <div className={`p-2.5 rounded-lg border text-center transition-all ${hasSpecial ? 'bg-emerald-950/15 border-emerald-500/30 text-emerald-400' : 'bg-slate-950/25 border-white/5 text-slate-600'}`}>
                <div className="text-[9px] font-mono uppercase text-slate-500">Symbols</div>
                <div className="text-xs font-bold mt-1 font-mono">{hasSpecial ? "PASSED" : "FAILED"}</div>
              </div>
            </div>

            {/* STRENGTH ANALYSER DISPLAY CARD (Result Output) */}
            <div className="bg-[#07080C] border border-white/5 rounded-xl p-4 md:p-5">
              <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3 mb-3">
                <div>
                  <dt className="text-[9px] uppercase tracking-widest text-slate-550 font-mono">Analyzed Password Strength</dt>
                  <dd className="flex items-baseline space-x-2 mt-0.5">
                    <span className={`text-2xl font-black ${strength.color}`}>
                      {strength.label}
                    </span>
                    <span className="text-[10px] text-slate-500 font-mono">({score} scores matched)</span>
                  </dd>
                </div>
                
                <div className="text-left sm:text-right">
                  <span className="text-[9px] uppercase tracking-widest text-slate-550 font-mono">Bruteforce Guard</span>
                  <div className="text-sm font-mono text-cyan-400 font-bold mt-0.5">
                    {score === 5 ? "MAXIMUM DEFENSE" : score >= 3 ? "STANDARD COVER" : "DANGEROUS / WEAK"}
                  </div>
                </div>
              </div>

              {/* Progress visual indicator bar */}
              <div className="h-2 bg-slate-950 rounded-full overflow-hidden flex gap-0.5">
                <div className={`h-full transition-all duration-350 ${score >= 1 ? 'bg-rose-500' : 'bg-white/5'} ${score === 1 ? 'w-full' : 'w-1/3'}`}></div>
                <div className={`h-full transition-all duration-350 ${score >= 3 ? 'bg-amber-500' : 'bg-white/5'} ${score >= 3 && score < 5 ? 'w-full' : 'w-1/3'}`}></div>
                <div className={`h-full transition-all duration-350 ${score === 5 ? 'bg-emerald-400' : 'bg-white/5'} ${score === 5 ? 'w-full' : 'w-1/3'}`}></div>
              </div>
            </div>

            {/* SMALL SECURITY TIPS LIST */}
            <div className="space-y-2 max-h-32 overflow-y-auto pr-1">
              <dt className="text-[9px] uppercase font-mono tracking-widest text-slate-400 flex items-center gap-1.5">
                <span className="w-1.5 h-1.5 rounded-full bg-cyan-400"></span> 
                Security Tips Suggested below result
              </dt>
              <ul className="space-y-1">
                {getSecurityTips().map((tip, idx) => (
                  <li key={idx} className="text-xs text-slate-400 flex items-start space-x-1.5 font-mono">
                    <span className="text-cyan-500 shrink-0">&#9654;</span>
                    <span>{tip}</span>
                  </li>
                ))}
              </ul>
            </div>

            {/* EVENT LOGS */}
            <div className="border border-white/5 bg-[#07080C] rounded-lg p-3.5">
              <div className="flex justify-between items-center mb-2 pb-1 bg-black/10">
                <span className="text-[9px] uppercase tracking-wider text-cyan-400 font-mono flex items-center gap-1.5">
                  <History className="h-3.5 w-3.5" /> Cyber Protection Real-time Logs
                </span>
                <span className="text-[8px] font-mono text-slate-500 bg-white/5 px-2 py-0.5 rounded">
                  LOGS
                </span>
              </div>
              <div className="space-y-1 font-mono max-h-24 overflow-y-auto text-[10px]">
                {logs.map((log, index) => (
                  <div key={index} className="flex space-x-2 leading-relaxed">
                    <span className="text-slate-600 select-none">[{log.timestamp}]</span>
                    <span className={`select-none ${
                      log.type === "error" ? "text-rose-500" :
                      log.type === "success" ? "text-emerald-400" :
                      log.type === "warning" ? "text-amber-500" : "text-cyan-700"
                    }`}>
                      {log.type === "error" ? "[LOCKOUT]" :
                       log.type === "success" ? "[ACCESS]" :
                       log.type === "warning" ? "[WARN]" : "[INFO]"}
                    </span>
                    <span className={log.type === "success" ? "text-emerald-350 font-bold" : log.type === "error" ? "text-rose-400" : "text-slate-350"}>
                      {log.text}
                    </span>
                  </div>
                ))}
              </div>
            </div>

            {/* LOWER SUBMIT TRIGGER TRIGGERS */}
            <div className="flex flex-wrap items-center justify-between gap-4 pt-4 border-t border-white/5">
              <button
                type="submit"
                className={`px-6 py-3 font-mono text-xs font-black rounded-xl cursor-pointer transition-all flex items-center gap-2 ${
                  isLocked 
                    ? "bg-rose-600 text-white hover:bg-rose-500 shadow-[0_0_15px_rgba(239,68,68,0.3)]" 
                    : "bg-cyan-500 text-black hover:bg-cyan-400 shadow-[0_4px_15px_rgba(34,211,238,0.25)]"
                }`}
              >
                <ShieldCheck className="h-4.5 w-4.5" />
                {isLocked ? "Unlock Account Successfully" : "Analyze & Verify Password"}
              </button>

              <div className="flex space-x-3 text-xs font-mono">
                {isLocked && (
                  <button
                    type="button"
                    onClick={() => {
                      setAttempts(0);
                      setAuthStatus("unlocked_success");
                      setFeedbackMessage("Account Unlocked Successfully");
                      setEnteredPassword("");
                      addLog("Purged lockout status. Authorized bypass initialized.", "success");
                    }}
                    className="text-cyan-500 hover:underline hover:text-cyan-400"
                  >
                    Standard Override Bypass
                  </button>
                )}
              </div>
            </div>
          </form>
        </div>

        {/* ADMIN CRIDENTIALS CALIBRATOR DRAWER */}
        <div className="w-full max-w-2xl mt-5 p-4 bg-[#0F1117]/80 border border-white/5 rounded-xl">
          <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3">
            <div className="flex items-center space-x-3 text-left">
              <div className="p-2 bg-gradient-to-br from-slate-900 to-[#101116] border border-white/5 rounded-lg">
                <Database className="h-4 w-4 text-cyan-400" />
              </div>
              <div>
                <span className="text-[9px] text-slate-500 uppercase tracking-widest font-mono block">Original Admin Password Configuration</span>
                <div className="flex items-center space-x-2 mt-1">
                  <span className="text-xs text-slate-400 font-mono">Master Password:</span>
                  <input 
                    type="text" 
                    value={targetPassword}
                    onChange={(e) => {
                      setTargetPassword(e.target.value);
                      addLog(`Updated system correct validation key to: "${e.target.value}".`, "warning");
                    }}
                    placeholder="Set Master Password..."
                    className="bg-black/80 border border-white/10 text-cyan-300 font-mono rounded px-2 py-0.5 text-xs focus:outline-none focus:border-cyan-500 w-48" 
                  /> 
                </div>
              </div>
            </div>

            <div className="text-[9.5px] text-slate-500 font-mono uppercase bg-slate-950/50 py-1 px-2.5 rounded border border-white/[0.02]">
              🔒 Local Client Sandbox
            </div>
          </div>
        </div>

      </main>

      {/* FOOTER METADATA */}
      <footer className="relative z-10 px-6 md:px-10 py-4 border-t border-white/5 bg-[#050608] flex flex-col sm:flex-row justify-between items-center gap-4">
        <div className="text-[10px] uppercase tracking-widest text-[#414856] font-mono">
          System Safeguard: Lockout state checks triggered on byte arrays
        </div>
        <div className="flex space-x-6">
          <div className="text-[10px] uppercase tracking-widest text-slate-500 flex items-center space-x-2">
            <span className="w-1.5 h-1.5 bg-cyan-500 rounded-full animate-ping"></span>
            <span>SIMULATOR ACTIVE</span>
          </div>
          <div className="text-[10px] uppercase tracking-widest text-slate-500 flex items-center space-x-2">
            <span className="w-1.5 h-1.5 bg-emerald-500 rounded-full"></span>
            <span>MEMORY SAFE</span>
          </div>
        </div>
      </footer>

    </div>
  );
}
